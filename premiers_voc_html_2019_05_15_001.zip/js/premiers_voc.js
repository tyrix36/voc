













function premiers_voc_main()
{

    console.log(" debut premiers_voc_main ");

    try
    {

        const dt_01 = new Date();
        const dt_02 = dt_01.toISOString();

        const html_01 = `
  <div class="voc_01">
    <span class="voc_01">
il est �dt_02� heure. </span>
  </div>
`;

        const html_02 = html_01.replace("�dt_02�", dt_02);

        console.log("");

        const app_balise =
            document.getElementById("app");

        console.log("");

        app_balise.innerHTML = "";
        app_balise.innerHTML += html_02;


        app_balise.innerHTML = premiers_voc_index_html;



        console.log("");
    }
    catch (ex)
    {

        console.log(" erreur : ");
        console.log(ex);
        console.log("");
    }


    console.log(" fin premiers_voc_main ");
    console.log("");

}
