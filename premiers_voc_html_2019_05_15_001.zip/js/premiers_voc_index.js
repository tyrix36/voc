﻿/// <reference path="lib/azuriljsoutil.js" />
//
//
"use strict";
//
// Create date : 2018-10-24
// Last update : 2018-10-26
// 
// TODO : 
// ? > MAJ des qcm
// ? > icon
// ? > titre_apli
// 
// 
// changelog : 
// 
// 2018-10-26 > titre menu
// 2018-10-26 > tout les boutons qcm cliqué
// 2018-10-26 > shuffle_02
// 

var g_tts = "";
var g_answer = "";
var g_url = "";
var g_total_question;
var g_good_answer;
var g_bad_answer;
var g_is_answered;


function randomInt(mini, maxi)
{
    var nb = mini + (maxi + 1 - mini) * Math.random();
    return Math.floor(nb);
}

Array.prototype.shuffle_02 = function (n)
{
    if (!n)
        n = this.length;
    if (n > 1)
    {
        var i = randomInt(0, n - 1);
        var tmp = this[i];
        this[i] = this[n - 1];
        this[n - 1] = tmp;
        this.shuffle_02(n - 1);
    }
}

function shuffle_01(a)
{
    var j, x, i;

    for (i = a.length - 1; i > 0; i--)
    {
        j = Math.floor(Math.random() * (i + 1));
        x = a[i];
        a[i] = a[j];
        a[j] = x;
    }

    return a;
}

function shuffle(a)
{
    a.shuffle_02();

    return a;
}

function bt_OnClick(url)
{

    g_url = url;

    //window.location.assign("qcm.html?csv=" + url);

    Exec_01();

}

function Get_Menu_ButtonForm(csv)
{

    const menu = document.getElementById("qcm_js");

    var ts_R = AzurilJs.Csv.getArrayFromCsv(csv);

    var ts_R = shuffle(ts_R);

    console.log();

    var html = "";

    for (let i = 0; i < ts_R.length; i++)
    {

        const r = ts_R[i][0];
        const url = ts_R[i][1];


        html +=
            '\
<button class="bt_voc mdl-js-ripple-effect mdl-button mdl-js-button mdl-button--raised mdl-button--colored" \
\
';

        html += ' onmouseup="bt_OnClick(\'' + url + '\');"';

        html += ' id="' + r + '"';

        html += ">" + r + "";

        html +=
            "\
</button>\
<br />\
";


        console.log();
    }

    menu.innerHTML += html;

    console.log();
}

function Get_Menu_Csv()
{

    var debug_01 = document.getElementById("debug_01");

    const debug_Link = document.getElementById("debug_link");

    const url = "csv/menu_csv.txt";

    debug_Link.innerText = '<a href="' + url + '">' + url + "</a>";

    console.log();

    var r = new XMLHttpRequest();

    r.open("GET", url, true);

    r.onreadystatechange = function ()
    {

        if (r.readyState !== 4 || r.status !== 200)
            return;

        const csv = r.responseText;

        debug_01.innerText = csv;

        Get_Menu_ButtonForm(csv);

        console.log();
    };

    r.send();

    console.log();
}

function Exec_Menu()
{

    const question = document.getElementById("question");
    question.innerText = "Menu";

    Get_Menu_Csv();

    console.log();
}

function bt_Qcm_OnClick(r)
{

    console.log(r);

    var l_bt_qcm = document.getElementsByClassName('bt_qcm');

    for (var i = 0; i < l_bt_qcm.length; ++i)
    {
        const bt = l_bt_qcm[i];
        const bt_text = bt.innerText;

        if (g_answer === bt_text)
        {
            bt.style.backgroundColor = "green";
        }
        else
        {
            bt.style.backgroundColor = "red";
        }

    }

    if (g_is_answered == 0)
    {

        if (g_answer === r)
        {
            g_good_answer++;
        }
        else
        {
            g_bad_answer++;
        }

    }


    document.getElementById("good_answer").innerText =
        " good answer : " + g_good_answer;

    document.getElementById("bad_answer").innerText =
        " bad answer : " + g_bad_answer;

    g_is_answered = 1;

    console.log(r);
}

function Get_RadioForm(ts_R)
{

    var html = "";
    console.log();

    for (let i = 0; i < ts_R.length; i++)
    {

        const r = ts_R[i];

        html +=
            '\
<div class="choice"> \
    <span class="mdl-list__item-secondary-action">\
                <label class="demo-list-radio mdl-radio mdl-js-radio mdl-js-ripple-effect" for="list-option-'+ i + '">\
                    <input type="radio" id="list-option-'+ i + '" class="mdl-radio__button" name="options" value="' + i + '" />\
\
';

        html += r;

        html +=
            "\
                    </label>\
            </span>\
            </div >\
    <br />\
";

    }

    console.log();

    return html;
}

function Get_ButtonForm(ts_R)
{

    //melange entre les reponses
    ts_R = shuffle(ts_R);

    var html = "";

    console.log();

    for (let i = 0; i < ts_R.length; i++)
    {

        const r = ts_R[i];


        html +=
            '\
<button style="" class="bt_qcm bt_voc mdl-js-ripple-effect mdl-button mdl-js-button mdl-button--raised mdl-button--colored" \
\
';

        html += ' onmouseup="bt_Qcm_OnClick(\'' + r + '\');"';

        html += ' id="' + r + '"';

        html += ">" + r + "";

        html +=
            "\
</button>\
<br />\
";


        console.log();
    }

    console.log();

    return html;
}

function Get_Form_From_Csv(tts)
{

    var html = "";


    // melange entre toutes les question reponce
    tts = shuffle(tts);


    console.log();

    const q1 = tts[0][0];

    const r1 = tts[0][1];
    const r2 = tts[1][1];
    const r3 = tts[2][1];
    const r4 = tts[3][1];

    const ts_R = [r1, r2, r3, r4];

    g_answer = r1;

    console.log();

    const question = document.getElementById("question");
    question.innerText = q1 + " ? ";

    html += Get_ButtonForm(ts_R);

    console.log();

    return html;
}

function Get_Csv(url)
{

    var debug_01 = document.getElementById("debug_01");
    var qcm_Js = document.getElementById("qcm_js");


    console.log();

    var r = new XMLHttpRequest();

    var ajaxUrl = url + "?cache=" + (Math.random() * 1000000);

    r.open("GET", ajaxUrl, true);

    r.onreadystatechange = function ()
    {
        if (r.readyState !== 4 || r.status !== 200)
            return;

        const csv = r.responseText;

        const tts = AzurilJs.Csv.getArrayFromCsv(csv);

        debug_01.innerText = csv;

        g_tts = tts;





        var nb_remaining_question = g_tts.length - 4;

        if (nb_remaining_question <= -1)
        {
            menu();
        }
        else
        {

            g_total_question = nb_remaining_question + 1;

            var num_question = g_total_question - nb_remaining_question;

            var total_question_balise = document.getElementById("total_question");
            total_question_balise.innerText = " question number : " + num_question + " / " + g_total_question

            var remaining_question_balise = document.getElementById("remaining_question");
            remaining_question_balise.innerText = " remaining question : " + nb_remaining_question

            var html = Get_Form_From_Csv(g_tts);

            qcm_Js.innerHTML = html;



            const div_Next = document.getElementById("div_next");

            html = "";

            html +=
                '\
<button class="bt_voc mdl-js-ripple-effect mdl-button mdl-js-button mdl-button--raised mdl-button--colored" \
\
';

            html += ' onmouseup="next();">next</button><br />';

            div_Next.innerHTML = html;

        }

        console.log();
    };

    r.send("banana=yellow");

    console.log();

}

function Exec_01()
{

    //const query_String = AzurilJs.Outil.getParam();

    //console.log(query_String);

    //const url = query_String["csv"];

    //const debugmode = query_String["d"];

    //if ("1" === debugmode)
    //{
    //    console.log("debugmode");

    //    const debug_01 = document.getElementById("debug_01");

    //    debug_01.style.display = "block";

    //}

    const div_Bt = document.getElementById("div_Bt");
    div_Bt.style.display = "flex";

    console.log();

    Get_Csv(g_url);

    console.log();

}

function removeFirst(array)
{
    array.shift();

    return array;
}

function next()
{
    console.log();


    g_is_answered = 0;
    g_tts = removeFirst(g_tts);


    var nb_remaining_question = g_tts.length - 4;

    if (nb_remaining_question <= -1)
    {
        menu();
    }
    else
    {

        var remaining_question_balise = document.getElementById("remaining_question");
        remaining_question_balise.innerText = " remaining question : " + nb_remaining_question

        var num_question = g_total_question - nb_remaining_question;

        var total_question_balise = document.getElementById("total_question");
        total_question_balise.innerText = " question number : " + num_question + " / " + g_total_question

        const html = Get_Form_From_Csv(g_tts);

        const qcm_Js = document.getElementById("qcm_js");
        qcm_Js.innerHTML = html;

    }

    console.log();
}

function reset()
{

    const div_Bt = document.getElementById("div_Bt");
    div_Bt.style.display = "none";

    document.getElementById("qcm_js").innerHTML = "";
    document.getElementById("debug_01").innerHTML = "";
    document.getElementById("debug_link").innerHTML = "";
    document.getElementById("remaining_question").innerText = "";
    document.getElementById("total_question").innerText = "";
    document.getElementById("good_answer").innerText = "";
    document.getElementById("bad_answer").innerText = "";

    g_total_question = 0;
    g_good_answer = 0;
    g_bad_answer = 0;
    g_tts = "";
    g_answer = "";
    g_is_answered = 0;



    console.log();
}

function menu()
{

    reset();

    Exec_Menu();

    console.log();
}

function init_01()
{

    g_url = "";

    reset();
    Exec_Menu();

    console.log();
}
