
console.log("");

const premiers_voc_index_html = `

<div class="screen_01">
        <div class="screen_02">
            <div>
                <h5 class="titre" id="question"></h5>
            </div>
            <div class="qcm">
                <div id="qcm_js" class="qcm_vertical">
                </div>
            </div>
            <div id="div_Bt" class="div_Bt">
                <button id="bt_Menu" style="" href="menu.html" onmouseup="menu();"
                        class="bt_voc mdl-js-ripple-effect mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
                    Menu
                </button>
                <div style="flex-grow:1;"></div>
                <div id="div_next"></div>
            </div>

            <p style="display:none" id="remaining_question"></p>
            <p id="total_question"></p>
            <p id="good_answer"></p>
            <p id="bad_answer"></p>



            <pre style="display:none" id="debug_01" class="debug"></pre>
            <span style="display:none" id="debug_link" class="debug"></span>
        </div>
    </div>
	
`;

console.log("");
