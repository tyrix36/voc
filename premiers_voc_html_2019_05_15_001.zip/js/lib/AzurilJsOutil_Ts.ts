﻿"use strict";

// Author      : Felix ROBICHON
// Create Date : 2015-06-30
// Last update : 2015-07-17
// Last update : 2017-09-04
// Last update : 2017-10-06
// Last update : 2018-01-25
// Last update : 2018-03-08
// Last update : 2018-03-09
// Last update : 2018-10-24


var azurilJsOutil_Ts:
    {

        os:
        {
            isArm: () => boolean;
            isInternetExplorer: () => boolean;
            isFirefox: () => boolean;
            getChromeVersion: () => number;
            isChrome: () => boolean;
            isFirefoxOrChrome: () => void;
            isX64: () => false | boolean;
        };
        outil:
        {
            debugMode: boolean;
            isset: () => boolean;
            seconde: () => string;
            displayConsole: (bool: any) => void;
            clearConsole: () => void;
            printLn: (s: any) => void;
            printLnErr: (s: any) => void;
            getText: (id_Balise: any) => string;
            getHtml: (id_Balise: any) => string;
            getValue: (id_Balise: any) => any;
            getUrlPath: () => string;
            getBaliseType: (balise: any) => any;
            redirection: (url: any) => void;
            dropDownListLast: (id_DropDownList: string) => void;
            dropDownListLenght: (id_DropDownList: string) => number;
            dropDownListSetSelect: (id_DropDownList: string, index: number) => void;
            getListFromDropDownList: (id_DropDownList: string) => any[];
            getIndexOf: (stringList: any[], item: any) => number;
            showLoading: (e: any) => void;
            clone: (array: any[]) => any[];
        };

        event:
        {
            isDigitKey: (evt: any) => boolean; isNumberKey: (evt: any) => boolean;
        }

    } = {

    os:
    {
        isArm()
        {
            return (navigator.userAgent.indexOf(" arm") !== -1);
        },

        isInternetExplorer()
        {

            const ua: string = navigator.userAgent;

            if (ua.indexOf("Trident") !== -1)
            {
                return true;
            }

            if (ua.indexOf("Edge") !== -1)
            {
                return true;
            }

            return false;
        },


        isFirefox()
        {

            if (navigator.userAgent.indexOf("Firefox") !== -1)
            {
                return true;
            }

            return false;
        },

        getChromeVersion()
        {
            const raw: RegExpMatchArray = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);

            return raw ? parseInt(raw[2], 10) : -1;
        },

        isChrome()
        {
            const chromeVersion: number = azurilJsOutil_Ts.os.getChromeVersion();

            if (chromeVersion === -1) 
            {
                return false;
            }

            return true;
        },

        isFirefoxOrChrome()
        {
            if (azurilJsOutil_Ts.os.isFirefox() || azurilJsOutil_Ts.os.getChromeVersion() >= 60)
            {

            }
        },

        isX64()
        {

            if (azurilJsOutil_Ts.os.isInternetExplorer())
            {
                return false;
            }

            const is_X64: boolean = (navigator.userAgent.indexOf(" x64") !== -1);

            const is_Wow64: boolean = (navigator.userAgent.indexOf(" WOW64") !== -1);

            const b: boolean = (is_X64 || is_Wow64);

            return b;
        }

    },

    outil:
    {

        debugMode: true
        ,

        isset()
        {
            // http://kevin.vanzonneveld.net
            // +   original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
            // +   improved by: FremyCompany
            // +   improved by: Onno Marsman
            // +   improved by: Rafał Kukawski
            // *     example 1: isset( undefined, true);
            // *     returns 1: false
            // *     example 2: isset( 'Kevin van Zonneveld' );
            // *     returns 2: true

            const a: IArguments = arguments;
            const l: number = a.length;
            let i: number = 0;
            let undef;

            if (l === 0)
            {
                throw new Error("Empty isset");
            }

            while (i !== l)
            {
                if (a[i] === undef || a[i] === null)
                {
                    return false;
                }
                i++;
            }
            return true;
        },

        seconde()
        {
            let r: string = "";

            if (this.debugMode)
            {

                try
                {
                    r = (new Date(Date.now())).toISOString();
                }
                catch (ex)
                {

                }

            }

            return r;
        },

        displayConsole(bool)
        {

            const balise_Style: CSSStyleDeclaration = document.getElementById("console").style;

            if (bool)
            {
                balise_Style.display = "block";
            }
            else
            {
                balise_Style.display = "none";
            }

        },


        clearConsole()
        {
            document.getElementById("console").innerHTML = "";
        },

        printLn(s)
        {
            if (this.debugMode && document.getElementById("console") != null)
            {
                document.getElementById("console").innerHTML += "<span class=\"line_console\" >" + this.seconde() + " : " + s + "</span><br />";
            }
        },

        printLnErr(s)
        {
            if (this.debugMode && document.getElementById("console") != null)
            {
                document.getElementById("console").innerHTML += "<span class=\"line_console_error\" >" + this.seconde() + " : " + s + "</span><br />";
            }
        },

        getText(id_Balise)
        {
            return document.getElementById(id_Balise).innerText;
        },

        getHtml(id_Balise)
        {
            return document.getElementById(id_Balise).innerHTML;
        },

        getValue(id_Balise)
        {
            return document.getElementById(id_Balise).nodeValue;
        },

        getUrlPath()
        {
            return window.location.pathname;
        },

        getBaliseType(balise)
        {
            return balise.tagName;
        },

        redirection(url)
        {
            window.location.assign(url);
        },

        //crash()
        //{
        //    const s = window.ts_bug[3];

        //    console.log(s);

        //    console.log(" notReachableVar : crash do not crash ");

        //},

        dropDownListLast(id_DropDownList)
        {
            const balise_DropDownList: HTMLSelectElement = (document.getElementById(id_DropDownList)) as HTMLSelectElement;

            try
            {
                balise_DropDownList.selectedIndex = balise_DropDownList.length - 1;
            }
            catch (ex)
            {
                const err: string = " Erreur javascript dans DropDownList_Last : " + ex.toString();
                azurilJsOutil_Ts.outil.displayConsole(true);
                azurilJsOutil_Ts.outil.printLnErr(err);
            }

        },

        dropDownListLenght(id_DropDownList)
        {
            const balise_DropDownList: HTMLSelectElement = (document.getElementById(id_DropDownList)) as HTMLSelectElement;
            const r: number = balise_DropDownList.childElementCount && balise_DropDownList.length;
            return r;
        },

        dropDownListSetSelect(id_DropDownList, index)
        {
            const balise_DropDownList: HTMLSelectElement = (document.getElementById(id_DropDownList)) as HTMLSelectElement;
            balise_DropDownList.selectedIndex = index;
        },


        //getListFromDropDownList(id_DropDownList)
        //{

        //    const balise_DropDownList: HTMLSelectElement = (document.getElementById(id_DropDownList)) as HTMLSelectElement;

        //    const i_Count: number = balise_DropDownList.childElementCount;

        //    var ddl: HTMLSelectElement =  balise_DropDownList;

        //    const e: HTMLElement = balise_DropDownList;

        //    const r: any[] = new Array(i_Count);

        //    for (let i: number = 0; i < i_Count; i++)
        //    {

        //        r[i] = e.options[i].value;

        //    }

        //    return r;
        //},

        getListFromDropDownList(id_DropDownList)
        {

            const ddl: HTMLSelectElement = (document.getElementById(id_DropDownList)) as HTMLSelectElement;

            const i_Count: number = ddl.childElementCount;

            const r: any[] = new Array(i_Count);

            for (let i: number = 0; i < i_Count; i++)
            {

                const local: string = ddl.options[i].value;

                r[i] = local;
            }

            return r;
        },

        getIndexOf(stringList, item)
        {

            let r: number = -1;

            const i_Count: number | Object = stringList.length;

            for (let i: number = 0; i < i_Count; i++)
            {
                // ReSharper disable once CoercedEqualsUsing
                if (stringList[i] == item)
                {
                    r = i;
                    return r;
                }
            }

            return r;
        },

        //getParam()
        //{

        //    // This function is anonymous, is executed immediately and 
        //    // the return value is assigned to QueryString!
        //    const query_String: {} = {};
        //    const query: string = window.location.search.substring(1);
        //    const vars: string[] = query.split("&");

        //    for (let i: number = 0; i < vars.length; i++)
        //    {

        //        const pair: string[] = vars[i].split("=");

        //        // If first entry with this name
        //        if (typeof query_String[pair[0]] === "undefined")
        //        {
        //            query_String[pair[0]] = pair[1];
        //            // If second entry with this name
        //        }
        //        else if (typeof query_String[pair[0]] === "string")
        //        {
        //            const arr: (any | string)[] = [query_String[pair[0]], pair[1]];
        //            query_String[pair[0]] = arr;
        //            // If third or later entry with this name
        //        } else
        //        {
        //            query_String[pair[0]].push(pair[1]);
        //        }

        //    }

        //    return query_String;

        //},

        // ReSharper disable once UnusedParameter
        showLoading(e)
        {

            const div: HTMLDivElement = document.createElement("div");
            const img: HTMLImageElement = document.createElement("img");

            //var img_Url = "http://www.oppenheim.com.au/wp-content/uploads/2007/08/ajax-loader-1.gif";
            const img_Url: "http://smallenvelop.com/wp-content/uploads/2014/08/Preloader_8.gif" = "http://smallenvelop.com/wp-content/uploads/2014/08/Preloader_8.gif";
            //var img_Url = "/ELVIA_GROUPE/images/Preloader_8.gif";

            img.src = img_Url;

            img.style.cssText = "max-width: 70%; max-width: 70vw; height : 50% ; height : 50vh ; ";
            div.innerHTML = "Loading...<br />";
            div.style.cssText = "position: fixed; top: 30%; left: 10%; z-index: 5000; width: 80%; width: 80vw; text-align: center; background: #fff; border: 1px solid #000 ; cursor: wait; font-size: 50pt;";
            div.appendChild(img);
            document.body.appendChild(div);

            // These 2 lines cancel form submission, so only use if needed.
            //window.event.cancelBubble = true;
            //e.stopPropagation();

        },

        clone(array)
        {

            if (azurilJsOutil_Ts.os.isChrome())
            {
                return array.slice();
            }

            return array.slice();
        }

    },

    event:
    {
        isDigitKey(evt)
        {

            const charCode: number | boolean | string = (evt.which) ? evt.which : evt.keyCode;

            if (charCode >= 48 && charCode <= 57)
                return true;

            return false;
        },

        isNumberKey(evt)
        {

            const charCode: number | boolean | string = (evt.which) ? evt.which : evt.keyCode;

            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;

            return true;
        }

    }




    //Async:
    //{

    //    sleep_Private: function (ms)
    //    {
    //        // ReSharper disable once UseOfImplicitGlobalInFunctionScope
    //        return new Promise(resolve => setTimeout(resolve, ms));
    //    },

    //    //async 
    //    sleep: function (ms)
    //    {

    //        // await 
    //        sleep(ms);
    //    },


    //    demo: function (ms)
    //    {
    //        console.log("Taking a break...");
    //        sleep(ms);
    //        console.log("Two second later");

    //    }
    //}



};

// end
